Config = {
SUDO_ID = {840965155}, --آیدی سودو های ربات
Full_Sudo = {840965155}, -- آیدی سودو اصلی
TD_ID = 1062654880, -- آیدی ربات
Sudoid = 840965155,-- آیدی سودو اصلی
BotHelper = 774852620, -- آیدی هلپر
UserBotHelper = '@HelperCompanybot', -- یوزرنیم هلپر
LinkSuppoRt = 'https://t.me/joinchat/N-5Hn1EwURAiVbzAWRyuJw', -- لینک گروه ساپورت
UserSudo = '@Remember_M_e', -- یوزرنیم سازنده
PvUserSudo = '@alisaber313', -- پیام رسان سازنده
Channel = '@alisaber313', -- یوزرنیم کانال 
ChannelInline = 'alisaber313', --یوزنیم کانال بدون @
RedisIndex = 1, -- شمار رديس را در اينجا قرار دهيد (اگر نمیدونید چی هست تغییری ایجاد نکنید) --> Redis:Select ...
token = '774852620:AAF9IAJMcyLy3Q6Hfw1fFy2VAY1yv9Nw2tM', -- توکن ربات api
}

return Config